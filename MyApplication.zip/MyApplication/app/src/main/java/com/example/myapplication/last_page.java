package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class last_page extends AppCompatActivity {

    Button exit_butt;
    TextView textView;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.last_page);

        exit_butt= (Button)findViewById(R.id.exit_button);
        textView= (TextView)findViewById(R.id.textView);

        textView.setText(getIntent().getStringExtra("NAME"));
    }
}
