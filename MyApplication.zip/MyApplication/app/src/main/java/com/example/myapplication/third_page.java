package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class third_page extends AppCompatActivity {

    Button thirdpreview_butt;
    Button thirdnext_butt;
    EditText editText;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.third_page);

        thirdpreview_butt= (Button)findViewById(R.id.third_preview_button);
        thirdnext_butt= (Button)findViewById(R.id.third_next_button);
        editText= (EditText)findViewById(R.id.username);


        thirdpreview_butt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int4= new Intent(third_page.this,second_page.class);
                startActivity(int4);
            }
        });
        thirdnext_butt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String namevalue=editText.getText().toString();
                Intent int5= new Intent(third_page.this,last_page.class);
                int5.putExtra("NAME", namevalue);
                startActivity(int5);
            }
        });
    }
}
